-- note記事自動作成ツール ライセンス管理 v1
-- Supabase SQL Editor で一度だけ実行してください。

create extension if not exists pgcrypto;

create table if not exists public.licenses (
  id uuid primary key default gen_random_uuid(),
  license_key text unique not null,
  customer_name text,
  is_active boolean not null default true,
  device_hash text,
  activated_at timestamptz,
  last_check_at timestamptz,
  created_at timestamptz not null default now()
);

alter table public.licenses enable row level security;

-- anon / authenticated からテーブルを直接読めないようにする
revoke all on table public.licenses from anon, authenticated;

create or replace function public.activate_license(p_license_key text, p_device_hash text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  rec public.licenses%rowtype;
begin
  select * into rec
  from public.licenses
  where license_key = trim(p_license_key)
  for update;

  if not found then
    return jsonb_build_object('valid', false, 'message', 'ライセンスキーが正しくありません。');
  end if;

  if not rec.is_active then
    return jsonb_build_object('valid', false, 'message', 'このライセンスは無効になっています。');
  end if;

  if rec.device_hash is null or rec.device_hash = '' then
    update public.licenses
      set device_hash = p_device_hash,
          activated_at = coalesce(activated_at, now()),
          last_check_at = now()
    where id = rec.id;
    return jsonb_build_object('valid', true, 'message', 'ライセンス認証が完了しました。', 'activated', true);
  end if;

  if rec.device_hash = p_device_hash then
    update public.licenses set last_check_at = now() where id = rec.id;
    return jsonb_build_object('valid', true, 'message', '認証済みです。', 'activated', false);
  end if;

  return jsonb_build_object('valid', false, 'message', 'このライセンスは別のPCですでに使用されています。');
end;
$$;

create or replace function public.check_license(p_license_key text, p_device_hash text)
returns jsonb
language plpgsql
security definer
set search_path = public
as $$
declare
  rec public.licenses%rowtype;
begin
  select * into rec
  from public.licenses
  where license_key = trim(p_license_key);

  if not found then
    return jsonb_build_object('valid', false, 'message', 'ライセンスキーが見つかりません。');
  end if;

  if not rec.is_active then
    return jsonb_build_object('valid', false, 'message', 'このライセンスは無効になっています。');
  end if;

  if rec.device_hash is null or rec.device_hash = '' then
    return jsonb_build_object('valid', false, 'message', 'このライセンスはまだPC認証されていません。');
  end if;

  if rec.device_hash <> p_device_hash then
    return jsonb_build_object('valid', false, 'message', 'このライセンスは別のPCに登録されています。');
  end if;

  update public.licenses set last_check_at = now() where id = rec.id;
  return jsonb_build_object('valid', true, 'message', '認証済みです。');
end;
$$;

grant execute on function public.activate_license(text, text) to anon, authenticated;
grant execute on function public.check_license(text, text) to anon, authenticated;

-- テスト用ライセンスを1件作る例：
-- insert into public.licenses (license_key, customer_name)
-- values ('NOTE-TEST-2026-ABCD-EFGH', 'テスト購入者');

-- PCを変更した購入者の認証をリセットする場合：
-- update public.licenses
-- set device_hash = null, activated_at = null
-- where license_key = 'NOTE-XXXX-XXXX-XXXX';
