Note AI Auto Maker V1 - Test Version

HOW TO START
1. Extract the ZIP file first.
2. Open the extracted folder.
3. Double-click START.cmd.
4. On the first run, required Python packages may be installed automatically.

If you see a Windows security message, confirm that you downloaded this file from the seller and choose to run it only if you trust it.

If START.cmd says Python was not found, Python 3 is not installed on the PC.

This is a development/test version. The final sales version is planned to run without requiring the buyer to set up Python manually.


【v1.2 追加仕様】
・APIキーはツール本体とは別のWindowsユーザー設定領域に保存します。
・同じWindowsユーザーで使う限り、ツールを新しいバージョンへ入れ替えても保存済みAPIキーを自動で引き継ぎます。
・APIキーはWindowsのDPAPIで暗号化して保存します。
・PC変更、Windowsユーザー変更、設定削除時は再入力が必要です。


【V1.3 変更点】
・左側の設定エリアを縦スクロール対応にしました。
・画面の高さが小さいPCでも「④画像生成」「⑤note投稿準備」まで操作できます。
・APIキーの保存先はV1.3と同じため、同じPC・同じWindowsユーザーでは引き継がれます。


【V1.3 修正】
・ツール表示名を「note記事自動作成ツール」に変更
・見出し画像は生成後および保存直前に必ず1280×670pxへ自動整形
・APIキー保存先は従来と同じため、同じPC・同じWindowsユーザーでは引き継がれます


【V2.3 変更点】
・タイトル生成を25〜35文字程度、最大40文字以内に調整しました。
・サブタイトル風の長い付け足しを避け、短く読みやすい1つのタイトルを生成します。
・APIキー保存先や記事・画像生成のその他の仕様は変更していません。


V2.3: note投稿画面へのタイトル・本文自動入力を追加。初回のみ専用Chromeでnoteログインが必要な場合があります。公開は自動で行いません。


V2.3: note自動入力時に目次を自動生成し、見出し・重要キーワードを太字で整形します。


V2.3: ツール上で目次・見出し・重要キーワードを太字表示し、目次更新ボタンを追加。


V2.3: 大見出し・小見出しの2階層生成、note標準目次の自動挿入を追加。


【v2.5 アップデート機能】
・最新版を確認
・更新履歴を見る
・GitHubから最新版ZIPを取得して自動更新
・APIキーはアップデート後も引き継ぎ
販売前に GITHUB_UPDATE_SETUP.txt を確認してください。
