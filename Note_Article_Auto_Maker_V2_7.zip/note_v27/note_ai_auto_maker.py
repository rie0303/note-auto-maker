import base64
import ctypes
import json
import html
import os
import re
import sys
import tempfile
import shutil
import subprocess
import threading
import urllib.error
import urllib.request
import webbrowser
import time
from ctypes import wintypes


class DATA_BLOB(ctypes.Structure):
    _fields_ = [("cbData", wintypes.DWORD), ("pbData", ctypes.POINTER(ctypes.c_byte))]
from datetime import datetime
from io import BytesIO
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext

APP_NAME = "note記事自動作成ツール V2.7"
APP_VERSION = "2.7"
TEXT_MODEL = "gpt-5-mini"
IMAGE_MODEL = "gpt-image-1"
RESPONSES_URL = "https://api.openai.com/v1/responses"
IMAGES_URL = "https://api.openai.com/v1/images/generations"
NOTE_NEW_URL = "https://note.com/new"
OPENAI_KEYS_URL = "https://platform.openai.com/api-keys"
OPENAI_BILLING_URL = "https://platform.openai.com/settings/organization/billing/overview"

APP_DIR = os.path.dirname(os.path.abspath(__file__))
UPDATE_CONFIG_PATH = os.path.join(APP_DIR, "update_config.json")
LOCAL_CHANGELOG_PATH = os.path.join(APP_DIR, "CHANGELOG.json")


def _version_tuple(value):
    nums = re.findall(r"\d+", str(value or ""))
    return tuple(int(x) for x in nums[:4]) or (0,)


def load_json_file(path, default=None):
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {} if default is None else default


def get_update_manifest_url():
    config = load_json_file(UPDATE_CONFIG_PATH, {})
    url = str(config.get("manifest_url", "")).strip()
    if "YOUR_" in url or "example.com" in url:
        return ""
    return url


def fetch_json(url, timeout=20):
    req = urllib.request.Request(url, headers={"User-Agent": f"NoteArticleAutoMaker/{APP_VERSION}"})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8"))


def download_file(url, path, timeout=120):
    req = urllib.request.Request(url, headers={"User-Agent": f"NoteArticleAutoMaker/{APP_VERSION}"})
    with urllib.request.urlopen(req, timeout=timeout) as resp, open(path, "wb") as f:
        shutil.copyfileobj(resp, f)


def build_temp_updater_script():
    code = 'import os, sys, time, zipfile, tempfile, shutil, subprocess\nzip_path, app_dir, pid = sys.argv[1], sys.argv[2], int(sys.argv[3])\nfor _ in range(100):\n    try:\n        os.kill(pid, 0)\n        time.sleep(0.2)\n    except Exception:\n        break\nwork = tempfile.mkdtemp(prefix="note_update_extract_")\ntry:\n    with zipfile.ZipFile(zip_path, "r") as z:\n        z.extractall(work)\n    entries = [os.path.join(work, n) for n in os.listdir(work)]\n    source = entries[0] if len(entries) == 1 and os.path.isdir(entries[0]) else work\n    for name in os.listdir(source):\n        if name == "update_config.json":\n            continue\n        src = os.path.join(source, name)\n        dst = os.path.join(app_dir, name)\n        if os.path.isdir(src):\n            os.makedirs(dst, exist_ok=True)\n            shutil.copytree(src, dst, dirs_exist_ok=True)\n        else:\n            shutil.copy2(src, dst)\n    start_cmd = os.path.join(app_dir, "START.cmd")\n    if os.path.exists(start_cmd):\n        subprocess.Popen(["cmd", "/c", "start", "", start_cmd], cwd=app_dir)\n    else:\n        subprocess.Popen([sys.executable, os.path.join(app_dir, "note_ai_auto_maker.py")], cwd=app_dir)\nfinally:\n    try:\n        shutil.rmtree(work, ignore_errors=True)\n        os.remove(zip_path)\n    except Exception:\n        pass\n'
    path = os.path.join(tempfile.gettempdir(), "note_article_auto_updater.py")
    with open(path, "w", encoding="utf-8") as f:
        f.write(code)
    return path


def app_data_dir():
    base = os.getenv("APPDATA") or os.path.expanduser("~")
    path = os.path.join(base, "NoteAIAutoMaker")
    os.makedirs(path, exist_ok=True)
    return path


SETTINGS_PATH = os.path.join(app_data_dir(), "settings.json")
NOTE_CHROME_PROFILE = os.path.join(app_data_dir(), "note_chrome_profile")


def _dpapi_encrypt(text: str) -> str:
    if os.name != "nt":
        return base64.b64encode(text.encode("utf-8")).decode("ascii")
    raw = text.encode("utf-8")
    in_buf = ctypes.create_string_buffer(raw)
    in_blob = DATA_BLOB(len(raw), ctypes.cast(in_buf, ctypes.POINTER(ctypes.c_byte)))
    out_blob = DATA_BLOB()
    if not ctypes.windll.crypt32.CryptProtectData(
        ctypes.byref(in_blob), None, None, None, None, 0, ctypes.byref(out_blob)
    ):
        raise ctypes.WinError()
    try:
        data = ctypes.string_at(out_blob.pbData, out_blob.cbData)
        return base64.b64encode(data).decode("ascii")
    finally:
        ctypes.windll.kernel32.LocalFree(out_blob.pbData)


def _dpapi_decrypt(token: str) -> str:
    data = base64.b64decode(token)
    if os.name != "nt":
        return data.decode("utf-8")
    in_buf = ctypes.create_string_buffer(data)
    in_blob = DATA_BLOB(len(data), ctypes.cast(in_buf, ctypes.POINTER(ctypes.c_byte)))
    out_blob = DATA_BLOB()
    if not ctypes.windll.crypt32.CryptUnprotectData(
        ctypes.byref(in_blob), None, None, None, None, 0, ctypes.byref(out_blob)
    ):
        raise ctypes.WinError()
    try:
        return ctypes.string_at(out_blob.pbData, out_blob.cbData).decode("utf-8")
    finally:
        ctypes.windll.kernel32.LocalFree(out_blob.pbData)


def load_settings():
    try:
        with open(SETTINGS_PATH, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_settings(data):
    with open(SETTINGS_PATH, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def response_text(data: dict) -> str:
    if isinstance(data.get("output_text"), str) and data["output_text"].strip():
        return data["output_text"].strip()
    parts = []
    for item in data.get("output", []):
        for content in item.get("content", []):
            text = content.get("text")
            if text:
                parts.append(text)
    return "\n".join(parts).strip()


def call_text_api(api_key: str, prompt: str, model: str = TEXT_MODEL, max_output_tokens: int = 5000) -> str:
    payload = {
        "model": model,
        "input": prompt,
        "max_output_tokens": max_output_tokens,
    }
    req = urllib.request.Request(
        RESPONSES_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=240) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace")
        try:
            detail = json.loads(detail).get("error", {}).get("message", detail)
        except Exception:
            pass
        raise RuntimeError(f"OpenAI API エラー ({e.code}): {detail}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"OpenAI APIへ接続できませんでした: {e.reason}") from e
    text = response_text(data)
    if not text:
        raise RuntimeError("AIから文章を取得できませんでした。")
    return text


def call_image_api(api_key: str, prompt: str, model: str = IMAGE_MODEL, quality: str = "medium") -> bytes:
    payload = {
        "model": model,
        "prompt": prompt,
        "size": "1536x1024",
        "quality": quality,
        "output_format": "png",
        "n": 1,
    }
    req = urllib.request.Request(
        IMAGES_URL,
        data=json.dumps(payload).encode("utf-8"),
        headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=300) as resp:
            data = json.loads(resp.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        detail = e.read().decode("utf-8", errors="replace")
        try:
            detail = json.loads(detail).get("error", {}).get("message", detail)
        except Exception:
            pass
        raise RuntimeError(f"画像生成API エラー ({e.code}): {detail}") from e
    except urllib.error.URLError as e:
        raise RuntimeError(f"画像生成APIへ接続できませんでした: {e.reason}") from e

    items = data.get("data") or []
    if not items:
        raise RuntimeError("画像データを取得できませんでした。")
    item = items[0]
    if item.get("b64_json"):
        return base64.b64decode(item["b64_json"])
    if item.get("url"):
        with urllib.request.urlopen(item["url"], timeout=120) as r:
            return r.read()
    raise RuntimeError("画像データ形式を認識できませんでした。")


def parse_article(raw: str):
    title = ""
    body = raw.strip()
    tags = ""
    m = re.search(r"(?:^|\n)タイトル\s*[:：]\s*(.+)", raw)
    if m:
        title = m.group(1).strip()
    m2 = re.search(r"(?:^|\n)ハッシュタグ\s*[:：]\s*(.+)", raw)
    if m2:
        tags = m2.group(1).strip()
    # body block if explicit marker exists
    bm = re.search(r"本文\s*[:：]\s*\n?(.*?)(?:\n\s*ハッシュタグ\s*[:：]|\Z)", raw, re.S)
    if bm:
        body = bm.group(1).strip()
    # remove title line if body fallback
    if not bm and m:
        body = re.sub(r"(?:^|\n)タイトル\s*[:：]\s*.+\n?", "", body, count=1).strip()
    return title, body, tags


def _load_japanese_font(size: int):
    from PIL import ImageFont
    candidates = [
        os.path.join(os.environ.get("WINDIR", "C:/Windows"), "Fonts", name)
        for name in ["YuGothB.ttc", "YuGothM.ttc", "meiryob.ttc", "meiryo.ttc", "msgothic.ttc", "arial.ttf"]
    ]
    for path in candidates:
        try:
            if os.path.exists(path):
                return ImageFont.truetype(path, size=size)
        except Exception:
            continue
    return ImageFont.load_default()


def _wrap_text_by_width(draw, text: str, font, max_width: int):
    text = re.sub(r"\s+", " ", text or "").strip()
    if not text:
        return []

    def width(s):
        bbox = draw.textbbox((0, 0), s, font=font)
        return bbox[2] - bbox[0]

    # Japanese-friendly char wrapping
    lines = []
    current = ""
    for ch in text:
        candidate = current + ch
        if current and width(candidate) > max_width:
            lines.append(current)
            current = ch
        else:
            current = candidate
    if current:
        lines.append(current)
    return [ln.strip() for ln in lines if ln.strip()]


def crop_note_cover(image_bytes: bytes, title: str = "") -> bytes:
    """Generate a note-ready 1280x670 PNG cover with clear title overlay."""
    try:
        from PIL import Image, ImageDraw
    except ImportError as e:
        raise RuntimeError("画像サイズ調整に必要なPillowが見つかりません。START.cmdから起動し直してください。") from e

    try:
        img = Image.open(BytesIO(image_bytes)).convert("RGB")
        target_w, target_h = 1280, 670

        # cover-fit crop
        scale = max(target_w / img.width, target_h / img.height)
        img = img.resize((max(1, int(round(img.width * scale))), max(1, int(round(img.height * scale)))), Image.LANCZOS)
        left = max(0, (img.width - target_w) // 2)
        top = max(0, (img.height - target_h) // 2)
        img = img.crop((left, top, left + target_w, top + target_h))

        base = img.convert("RGBA")

        # Stronger readability panel on left-bottom area
        panel = Image.new("RGBA", (target_w, target_h), (0, 0, 0, 0))
        draw_panel = ImageDraw.Draw(panel)
        draw_panel.rounded_rectangle((40, 380, 720, 620), radius=24, fill=(24, 33, 48, 170))
        # soft full-image gradient for extra readability
        for y in range(target_h):
            alpha = int(50 * (y / target_h))
            draw_panel.line((0, y, target_w, y), fill=(0, 0, 0, alpha))
        base = Image.alpha_composite(base, panel)

        clean_title = re.sub(r"\s+", " ", (title or "").strip())
        if clean_title:
            draw = ImageDraw.Draw(base)
            max_text_width = 620
            font_size = 60
            lines = []
            line_h = 0
            while font_size >= 28:
                font = _load_japanese_font(font_size)
                lines = _wrap_text_by_width(draw, clean_title, font, max_text_width)
                if len(lines) > 3:
                    font_size -= 4
                    continue
                line_box = draw.textbbox((0, 0), "あA", font=font)
                line_h = line_box[3] - line_box[1]
                total_h = len(lines) * line_h + max(0, len(lines)-1) * 12
                if total_h <= 180:
                    break
                font_size -= 4
            else:
                font = _load_japanese_font(28)
                lines = _wrap_text_by_width(draw, clean_title, font, max_text_width)[:3]
                line_h = draw.textbbox((0,0), "あA", font=font)[3] - draw.textbbox((0,0), "あA", font=font)[1]

            if len(lines) > 3:
                lines = lines[:3]
            if lines:
                last = lines[-1]
                while draw.textbbox((0,0), last + "…", font=font)[2] > max_text_width and len(last) > 1:
                    last = last[:-1]
                if last != lines[-1]:
                    lines[-1] = last + "…"

            y = 430
            for line in lines:
                x = 76
                # outline shadow
                for dx, dy in [(-2,0),(2,0),(0,-2),(0,2),(2,2),(-2,2),(2,-2),(-2,-2)]:
                    draw.text((x+dx, y+dy), line, font=font, fill=(16, 22, 34, 200))
                draw.text((x, y), line, font=font, fill=(255, 255, 255, 255))
                y += line_h + 12

        out = BytesIO()
        final = base.convert("RGB")
        final.save(out, format="PNG", optimize=True)
        result = out.getvalue()
        check = Image.open(BytesIO(result))
        if check.size != (target_w, target_h):
            raise RuntimeError("見出し画像を1280×670pxに変換できませんでした。")
        return result
    except RuntimeError:
        raise
    except Exception as e:
        raise RuntimeError(f"見出し画像の1280×670px変換に失敗しました: {e}") from e


def _heading_level(line: str):
    s = re.sub(r"\s+", " ", (line or "").strip())
    if not s:
        return 0
    if s.startswith("◆ ") or s == "◆":
        return 2
    if s.startswith("◇ ") or s == "◇":
        return 3
    if s in {"はじめに", "まとめ", "おわりに", "さいごに", "最後に"}:
        return 2
    if re.match(r"^[■●▼▽★☆◎◉▶▷□⚫︎]+\s*", s):
        return 2
    return 0


def _clean_heading(line: str) -> str:
    s = re.sub(r"\s+", " ", (line or "").strip())
    s = re.sub(r"^[◆◇■●▼▽★☆◎◉▶▷□⚫︎]+\s*", "", s).strip()
    return s


def _is_note_heading(line: str) -> bool:
    return _heading_level(line) in (2, 3)


def _bold_keywords_html(escaped_text: str) -> str:
    words = ["ポイント", "コツ", "注意", "おすすめ", "重要", "結論", "原因", "対策", "メリット", "デメリット"]
    out = escaped_text
    for word in words:
        out = re.sub(re.escape(word), f"<strong>{word}</strong>", out)
    return out


def extract_note_heading_items(body: str):
    items = []
    for ln in (body or "").replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        s = ln.strip()
        level = _heading_level(s)
        if level:
            clean = _clean_heading(s)
            if clean:
                items.append((level, clean))
    return items


def extract_note_headings(body: str):
    return [title for _, title in extract_note_heading_items(body)]


def strip_existing_toc(body: str):
    lines = (body or "").replace("\r\n", "\n").replace("\r", "\n").split("\n")
    out = []
    i = 0
    while i < len(lines):
        if lines[i].strip() == "目次":
            i += 1
            while i < len(lines):
                s = lines[i].strip()
                if not s or s.startswith("・") or s.startswith("└") or s.startswith("　└"):
                    i += 1
                    continue
                break
            continue
        out.append(lines[i])
        i += 1
    return "\n".join(out).strip()


def inject_note_toc(body: str):
    clean_body = strip_existing_toc(body)
    items = extract_note_heading_items(clean_body)
    if not items:
        return clean_body

    toc_lines = ["目次"]
    for level, title in items:
        if level == 2:
            toc_lines.append(f"・{title}")
        else:
            toc_lines.append(f"　└ {title}")

    # Keep the short lead paragraph(s) before the TOC. Insert the TOC immediately
    # before the first actual heading so the flow becomes:
    # title -> lead -> TOC -> はじめに -> article body.
    lines = clean_body.replace("\r\n", "\n").replace("\r", "\n").split("\n")
    first_heading = None
    for i, ln in enumerate(lines):
        if _heading_level(ln.strip()):
            first_heading = i
            break
    if first_heading is None:
        return "\n".join(toc_lines) + "\n\n" + clean_body

    lead_lines = lines[:first_heading]
    rest_lines = lines[first_heading:]
    while lead_lines and not lead_lines[-1].strip():
        lead_lines.pop()
    lead = "\n".join(lead_lines).strip()
    rest = "\n".join(rest_lines).strip()
    toc = "\n".join(toc_lines)
    if lead:
        return lead + "\n\n" + toc + "\n\n" + rest
    return toc + "\n\n" + rest


def build_note_html(body: str):
    clean_body = strip_existing_toc(body)
    raw_lines = [ln.rstrip() for ln in clean_body.replace("\r\n", "\n").replace("\r", "\n").split("\n")]
    items = extract_note_heading_items(clean_body)
    parts = ['<p><br></p>']
    for ln in raw_lines:
        s = ln.strip()
        if not s:
            parts.append('<p><br></p>')
            continue
        level = _heading_level(s)
        if level == 2:
            parts.append(f'<h2>{html.escape(_clean_heading(s))}</h2>')
        elif level == 3:
            parts.append(f'<h3>{html.escape(_clean_heading(s))}</h3>')
        elif re.match(r"^[-・]\s*", s):
            item = re.sub(r"^[-・]\s*", "", s)
            parts.append(f'<p>・{_bold_keywords_html(html.escape(item))}</p>')
        else:
            parts.append(f'<p>{_bold_keywords_html(html.escape(s))}</p>')
    return ''.join(parts), items


class NoteAIAutoMaker(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title(APP_NAME)
        self.geometry("1320x840")
        self.minsize(1120, 700)
        self.configure(bg="#f6f7fb")
        self.image_bytes = None
        self.preview_photo = None
        self.note_driver = None
        self.settings = load_settings()
        self.remote_update_manifest = None
        self._setup_style()
        self._build_ui()
        self._load_saved_settings()
        self.after(1800, self._silent_update_check)

    def _setup_style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except Exception:
            pass
        style.configure("TFrame", background="#f6f7fb")
        style.configure("Card.TFrame", background="#ffffff")
        style.configure("TLabel", background="#f6f7fb", foreground="#25304a", font=("Yu Gothic UI", 10))
        style.configure("Card.TLabel", background="#ffffff", foreground="#25304a", font=("Yu Gothic UI", 10))
        style.configure("Title.TLabel", background="#f6f7fb", foreground="#17213a", font=("Yu Gothic UI", 20, "bold"))
        style.configure("Section.TLabel", background="#ffffff", foreground="#17213a", font=("Yu Gothic UI", 12, "bold"))
        style.configure("Subtle.TLabel", background="#ffffff", foreground="#68708a", font=("Yu Gothic UI", 9))
        style.configure("Primary.TButton", font=("Yu Gothic UI", 10, "bold"), padding=(14, 10))
        style.configure("TButton", font=("Yu Gothic UI", 9), padding=(10, 7))
        style.configure("TEntry", padding=7)
        style.configure("TCombobox", padding=6)

    def _build_ui(self):
        root = ttk.Frame(self)
        root.pack(fill="both", expand=True, padx=18, pady=14)

        header = ttk.Frame(root)
        header.pack(fill="x", pady=(0, 12))
        ttk.Label(header, text="note記事自動作成ツール", style="Title.TLabel").pack(side="left")
        ttk.Label(header, text="テーマから記事と見出し画像を自動作成", foreground="#68708a").pack(side="left", padx=(14, 0), pady=(8, 0))
        self.status_var = tk.StringVar(value="準備OK")
        ttk.Label(header, textvariable=self.status_var, foreground="#4a6cf7").pack(side="right", pady=(8, 0))

        stepbar = tk.Frame(root, bg="#f6f7fb")
        stepbar.pack(fill="x", pady=(0, 12))
        for i, text in enumerate(["1  API設定", "2  記事設定", "3  記事生成", "4  画像生成", "5  note投稿準備"]):
            lbl = tk.Label(stepbar, text=text, bg="#ffffff", fg="#33415c", font=("Yu Gothic UI", 9, "bold"), padx=16, pady=9, bd=0)
            lbl.pack(side="left", padx=(0, 8))

        main = ttk.Panedwindow(root, orient="horizontal")
        main.pack(fill="both", expand=True)

        left = ttk.Frame(main, style="Card.TFrame", width=430)
        right = ttk.Frame(main, style="Card.TFrame")
        main.add(left, weight=0)
        main.add(right, weight=1)

        self._build_left(left)
        self._build_right(right)

    def _card_sep(self, parent):
        ttk.Separator(parent, orient="horizontal").pack(fill="x", pady=12)

    def _build_left(self, left):
        # 左側は小さい画面でも④画像生成・⑤note投稿準備まで操作できるよう
        # Canvas + Scrollbar で縦スクロール対応にする。
        shell = ttk.Frame(left, style="Card.TFrame")
        shell.pack(fill="both", expand=True)

        canvas = tk.Canvas(shell, bg="#ffffff", highlightthickness=0, bd=0)
        scrollbar = ttk.Scrollbar(shell, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)

        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)

        pad = ttk.Frame(canvas, style="Card.TFrame")
        window_id = canvas.create_window((0, 0), window=pad, anchor="nw")

        def _sync_scrollregion(event=None):
            canvas.configure(scrollregion=canvas.bbox("all"))

        def _sync_width(event):
            canvas.itemconfigure(window_id, width=event.width)

        pad.bind("<Configure>", _sync_scrollregion)
        canvas.bind("<Configure>", _sync_width)

        def _on_mousewheel(event):
            # Windows / macOS
            if getattr(event, "delta", 0):
                canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")
            else:
                # Linux fallback
                if getattr(event, "num", None) == 4:
                    canvas.yview_scroll(-1, "units")
                elif getattr(event, "num", None) == 5:
                    canvas.yview_scroll(1, "units")

        def _bind_wheel(_event=None):
            canvas.bind_all("<MouseWheel>", _on_mousewheel)
            canvas.bind_all("<Button-4>", _on_mousewheel)
            canvas.bind_all("<Button-5>", _on_mousewheel)

        def _unbind_wheel(_event=None):
            canvas.unbind_all("<MouseWheel>")
            canvas.unbind_all("<Button-4>")
            canvas.unbind_all("<Button-5>")

        canvas.bind("<Enter>", _bind_wheel)
        canvas.bind("<Leave>", _unbind_wheel)
        pad.bind("<Enter>", _bind_wheel)

        # 内側余白。各セクションはこのフレームに配置する。
        inner = ttk.Frame(pad, style="Card.TFrame")
        inner.pack(fill="both", expand=True, padx=18, pady=16)
        pad = inner

        ttk.Label(pad, text="① API設定", style="Section.TLabel").pack(anchor="w")
        ttk.Label(pad, text="文章生成と画像生成で同じOpenAI APIキーを使用します。", style="Subtle.TLabel").pack(anchor="w", pady=(2, 8))
        api_row = ttk.Frame(pad, style="Card.TFrame")
        api_row.pack(fill="x")
        self.api_var = tk.StringVar()
        self.api_entry = ttk.Entry(api_row, textvariable=self.api_var, show="●")
        self.api_entry.pack(side="left", fill="x", expand=True)
        self.show_api_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(api_row, text="表示", variable=self.show_api_var, command=self._toggle_api).pack(side="left", padx=(8, 0))

        save_row = ttk.Frame(pad, style="Card.TFrame")
        save_row.pack(fill="x", pady=(8, 0))
        self.save_api_var = tk.BooleanVar(value=True)
        ttk.Checkbutton(save_row, text="このPCに安全に保存", variable=self.save_api_var).pack(side="left")
        ttk.Button(save_row, text="接続テスト", command=self.test_api).pack(side="right")

        api_links = ttk.Frame(pad, style="Card.TFrame")
        api_links.pack(fill="x", pady=(8, 0))
        ttk.Button(api_links, text="APIキー取得", command=lambda: webbrowser.open(OPENAI_KEYS_URL)).pack(side="left")
        ttk.Button(api_links, text="API料金確認", command=lambda: webbrowser.open(OPENAI_BILLING_URL)).pack(side="left", padx=(8, 0))

        self._card_sep(pad)
        ttk.Label(pad, text="② 記事設定", style="Section.TLabel").pack(anchor="w")
        ttk.Label(pad, text="テーマ", style="Card.TLabel").pack(anchor="w", pady=(8, 2))
        self.theme_var = tk.StringVar()
        ttk.Entry(pad, textvariable=self.theme_var).pack(fill="x")

        form = ttk.Frame(pad, style="Card.TFrame")
        form.pack(fill="x", pady=(10, 0))
        ttk.Label(form, text="ジャンル", style="Card.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(form, text="記事タイプ", style="Card.TLabel").grid(row=0, column=1, sticky="w", padx=(10, 0))
        self.genre_var = tk.StringVar(value="副業")
        self.type_var = tk.StringVar(value="ノウハウ")
        genres = ["副業", "美容", "ダイエット", "暮らし", "仕事", "子育て", "レビュー", "その他"]
        types = ["ノウハウ", "体験談", "まとめ", "商品紹介", "初心者向け解説", "比較"]
        ttk.Combobox(form, textvariable=self.genre_var, values=genres, state="readonly", width=18).grid(row=1, column=0, sticky="ew", pady=(4, 0))
        ttk.Combobox(form, textvariable=self.type_var, values=types, state="readonly", width=18).grid(row=1, column=1, sticky="ew", padx=(10, 0), pady=(4, 0))
        form.columnconfigure(0, weight=1)
        form.columnconfigure(1, weight=1)

        form2 = ttk.Frame(pad, style="Card.TFrame")
        form2.pack(fill="x", pady=(10, 0))
        ttk.Label(form2, text="想定読者", style="Card.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(form2, text="文字数目安", style="Card.TLabel").grid(row=0, column=1, sticky="w", padx=(10, 0))
        self.reader_var = tk.StringVar(value="初心者")
        self.length_var = tk.StringVar(value="3000")
        ttk.Entry(form2, textvariable=self.reader_var).grid(row=1, column=0, sticky="ew", pady=(4, 0))
        ttk.Combobox(form2, textvariable=self.length_var, values=["1500", "2500", "3000", "5000", "8000"], state="readonly", width=12).grid(row=1, column=1, sticky="ew", padx=(10, 0), pady=(4, 0))
        form2.columnconfigure(0, weight=1)
        form2.columnconfigure(1, weight=1)

        ttk.Label(pad, text="文章の雰囲気", style="Card.TLabel").pack(anchor="w", pady=(10, 2))
        self.tone_var = tk.StringVar(value="読みやすく親しみやすい")
        ttk.Combobox(pad, textvariable=self.tone_var, values=["読みやすく親しみやすい", "やさしく丁寧", "専門的で信頼感重視", "テンポよくカジュアル", "シンプルで簡潔"], state="readonly").pack(fill="x")

        self._card_sep(pad)
        ttk.Label(pad, text="③ 記事生成", style="Section.TLabel").pack(anchor="w")
        ttk.Button(pad, text="AIでnote記事を作成", style="Primary.TButton", command=self.generate_article).pack(fill="x", pady=(8, 0))

        self._card_sep(pad)
        ttk.Label(pad, text="④ 画像生成", style="Section.TLabel").pack(anchor="w")
        img_form = ttk.Frame(pad, style="Card.TFrame")
        img_form.pack(fill="x", pady=(8, 0))
        self.image_style_var = tk.StringVar(value="おしゃれ")
        self.image_quality_var = tk.StringVar(value="medium")
        ttk.Label(img_form, text="テイスト", style="Card.TLabel").grid(row=0, column=0, sticky="w")
        ttk.Label(img_form, text="品質", style="Card.TLabel").grid(row=0, column=1, sticky="w", padx=(10, 0))
        ttk.Combobox(img_form, textvariable=self.image_style_var, values=["おしゃれ", "シンプル", "写真風", "イラスト", "ビジネス", "美容", "副業"], state="readonly").grid(row=1, column=0, sticky="ew", pady=(4, 0))
        ttk.Combobox(img_form, textvariable=self.image_quality_var, values=["low", "medium", "high"], state="readonly", width=10).grid(row=1, column=1, sticky="ew", padx=(10, 0), pady=(4, 0))
        img_form.columnconfigure(0, weight=1)
        img_form.columnconfigure(1, weight=1)
        ttk.Button(pad, text="見出し画像をAIで作成", command=self.generate_image).pack(fill="x", pady=(8, 0))
        ttk.Button(pad, text="画像を保存", command=self.save_image).pack(fill="x", pady=(6, 0))

        self._card_sep(pad)
        ttk.Label(pad, text="⑤ note投稿準備", style="Section.TLabel").pack(anchor="w")
        action = ttk.Frame(pad, style="Card.TFrame")
        action.pack(fill="x", pady=(8, 0))
        ttk.Button(action, text="タイトルコピー", command=self.copy_title).pack(side="left", expand=True, fill="x")
        ttk.Button(action, text="本文コピー", command=self.copy_body).pack(side="left", expand=True, fill="x", padx=(6, 0))
        ttk.Button(action, text="ハッシュタグコピー", command=self.copy_tags).pack(side="left", expand=True, fill="x", padx=(6, 0))
        ttk.Button(pad, text="noteへ整形して自動入力", command=self.auto_fill_note).pack(fill="x", pady=(8, 0))
        ttk.Button(pad, text="noteの新規投稿画面を開く（手動）", command=lambda: webbrowser.open(NOTE_NEW_URL)).pack(fill="x", pady=(6, 0))
        ttk.Button(pad, text="記事をTXT保存", command=self.save_text).pack(fill="x", pady=(6, 0))

        self._card_sep(pad)
        ttk.Label(pad, text="⑥ アップデート", style="Section.TLabel").pack(anchor="w")
        self.update_status_var = tk.StringVar(value=f"現在のバージョン：v{APP_VERSION}")
        self.update_status_label = tk.Label(
            pad,
            textvariable=self.update_status_var,
            bg="#ffffff",
            fg="#68708a",
            font=("Yu Gothic UI", 9),
            anchor="w",
            justify="left",
            padx=8,
            pady=6,
            wraplength=340,
        )
        self.update_status_label.pack(fill="x", anchor="w", pady=(6, 0))
        update_row = ttk.Frame(pad, style="Card.TFrame")
        update_row.pack(fill="x", pady=(6, 0))
        ttk.Button(update_row, text="最新版を確認", command=self.check_for_updates).pack(side="left", expand=True, fill="x")
        ttk.Button(update_row, text="更新履歴を見る", command=self.show_update_history).pack(side="left", expand=True, fill="x", padx=(6, 0))
        self.update_button = ttk.Button(pad, text="アップデート", command=self.install_update, state="disabled")
        self.update_button.pack(fill="x", pady=(6, 0))

        ttk.Label(pad, text="※公開前に必ず内容を確認してください。API利用料は購入者負担です。", style="Subtle.TLabel", wraplength=360).pack(anchor="w", pady=(12, 0))

    def _build_right(self, right):
        pad = ttk.Frame(right, style="Card.TFrame")
        pad.pack(fill="both", expand=True, padx=18, pady=16)

        title_row = ttk.Frame(pad, style="Card.TFrame")
        title_row.pack(fill="x")
        ttk.Label(title_row, text="生成結果・編集", style="Section.TLabel").pack(side="left")
        self.char_count_var = tk.StringVar(value="0文字")
        ttk.Label(title_row, textvariable=self.char_count_var, style="Subtle.TLabel").pack(side="right")

        ttk.Label(pad, text="タイトル", style="Card.TLabel").pack(anchor="w", pady=(10, 2))
        self.title_var = tk.StringVar()
        ttk.Entry(pad, textvariable=self.title_var, font=("Yu Gothic UI", 12, "bold")).pack(fill="x")

        body_frame = ttk.Frame(pad, style="Card.TFrame")
        body_frame.pack(fill="both", expand=True, pady=(10, 0))

        body_header = ttk.Frame(body_frame, style="Card.TFrame")
        body_header.pack(fill="x")
        ttk.Label(body_header, text="本文（大見出し・小見出し・目次を確認しながら編集できます）", style="Card.TLabel").pack(side="left")
        ttk.Button(body_header, text="目次を更新", command=self.refresh_toc).pack(side="right")

        self.body_text = scrolledtext.ScrolledText(body_frame, wrap="word", height=14, font=("Yu Gothic UI", 10), undo=True, bd=1, relief="solid")
        self.body_text.pack(fill="both", expand=True, pady=(4, 0))
        self.body_text.tag_configure("heading_big", font=("Yu Gothic UI", 12, "bold"), spacing1=10, spacing3=5)
        self.body_text.tag_configure("heading_small", font=("Yu Gothic UI", 10, "bold"), spacing1=6, spacing3=3, lmargin1=10, lmargin2=10)
        self.body_text.tag_configure("toc_title", font=("Yu Gothic UI", 11, "bold"), spacing1=6, spacing3=3)
        self.body_text.tag_configure("toc_item", lmargin1=18, lmargin2=18, foreground="#4f5b73")
        self.body_text.tag_configure("toc_subitem", lmargin1=36, lmargin2=36, foreground="#68708a")
        self.body_text.tag_configure("keyword", font=("Yu Gothic UI", 10, "bold"))
        self.body_text.bind("<KeyRelease>", self._on_body_keyrelease)

        tags_row = ttk.Frame(body_frame, style="Card.TFrame")
        tags_row.pack(fill="x", pady=(8, 0))
        ttk.Label(tags_row, text="ハッシュタグ", style="Card.TLabel").pack(side="left")
        self.tags_var = tk.StringVar()
        ttk.Entry(tags_row, textvariable=self.tags_var).pack(side="left", fill="x", expand=True, padx=(8, 0))

        image_frame = ttk.Frame(pad, style="Card.TFrame")
        image_frame.pack(fill="both", expand=False, pady=(10, 0))
        img_header = ttk.Frame(image_frame, style="Card.TFrame")
        img_header.pack(fill="x")
        ttk.Label(img_header, text="見出し画像プレビュー", style="Card.TLabel").pack(side="left")
        ttk.Label(img_header, text="縦横スクロールで全体確認できます", style="Subtle.TLabel").pack(side="right")

        preview_shell = ttk.Frame(image_frame, style="Card.TFrame")
        preview_shell.pack(fill="both", expand=False, pady=(4, 0))
        preview_shell.columnconfigure(0, weight=1)
        preview_shell.rowconfigure(0, weight=1)

        self.image_canvas = tk.Canvas(preview_shell, bg="#eef1f7", highlightthickness=0, height=390)
        self.image_xscroll = ttk.Scrollbar(preview_shell, orient="horizontal", command=self.image_canvas.xview)
        self.image_yscroll = ttk.Scrollbar(preview_shell, orient="vertical", command=self.image_canvas.yview)
        self.image_canvas.configure(xscrollcommand=self.image_xscroll.set, yscrollcommand=self.image_yscroll.set)

        self.image_canvas.grid(row=0, column=0, sticky="nsew")
        self.image_yscroll.grid(row=0, column=1, sticky="ns")
        self.image_xscroll.grid(row=1, column=0, sticky="ew")
        self.image_canvas.create_text(20, 20, anchor="nw", text="まだ画像は生成されていません", fill="#7b849d", font=("Yu Gothic UI", 10))
        self.image_canvas.bind("<Configure>", lambda e: self._render_preview())

    def _load_saved_settings(self):
        if self.settings.get("api_key"):
            try:
                self.api_var.set(_dpapi_decrypt(self.settings["api_key"]))
            except Exception:
                pass
        self.save_api_var.set(bool(self.settings.get("save_api", True)))

    def _toggle_api(self):
        self.api_entry.configure(show="" if self.show_api_var.get() else "●")

    def _persist_api(self):
        data = self.settings.copy()
        data["save_api"] = self.save_api_var.get()
        if self.save_api_var.get() and self.api_var.get().strip():
            data["api_key"] = _dpapi_encrypt(self.api_var.get().strip())
        else:
            data.pop("api_key", None)
        save_settings(data)
        self.settings = data

    def _require_api(self):
        key = self.api_var.get().strip()
        if not key:
            messagebox.showwarning("APIキー未入力", "OpenAI APIキーを入力してください。")
            return None
        self._persist_api()
        return key

    def _run_bg(self, work, success=None, busy="処理中..."):
        self.status_var.set(busy)
        self.config(cursor="watch")
        def runner():
            try:
                result = work()
                self.after(0, lambda: self._bg_success(result, success))
            except Exception as e:
                self.after(0, lambda: self._bg_error(e))
        threading.Thread(target=runner, daemon=True).start()

    def _bg_success(self, result, success):
        self.config(cursor="")
        self.status_var.set("完了")
        if success:
            success(result)

    def _bg_error(self, err):
        self.config(cursor="")
        self.status_var.set("エラー")
        messagebox.showerror("エラー", str(err))

    def test_api(self):
        key = self._require_api()
        if not key:
            return
        def work():
            return call_text_api(key, "『接続OK』の4文字だけを返してください。", max_output_tokens=30)
        def done(result):
            messagebox.showinfo("接続テスト", "OpenAI APIへ接続できました。\n\n" + result[:100])
        self._run_bg(work, done, "API接続を確認中...")

    def build_article_prompt(self):
        theme = self.theme_var.get().strip()
        if not theme:
            raise ValueError("テーマを入力してください。")
        return f"""あなたはnote記事の編集者です。以下の条件で、日本語のnote記事を1本作成してください。

テーマ: {theme}
ジャンル: {self.genre_var.get()}
記事タイプ: {self.type_var.get()}
想定読者: {self.reader_var.get()}
文字数目安: 約{self.length_var.get()}文字
文章の雰囲気: {self.tone_var.get()}

条件:
・読者が続きを読みたくなる自然なタイトルにする
・タイトルは25〜35文字程度を目安にし、長くても40文字以内にする
・サブタイトルは作らず、ダッシュや記号で説明を長く付け足さない
・ひと目で記事内容が伝わる、短く読みやすい1つのタイトルにする
・本文の最初に、記事全体を案内する短い導入文を2〜4文入れる
・この導入文は「◆ はじめに」より前に置き、見出し記号は付けない
・導入文では、この記事で分かること・読める内容を自然に案内する
・本文は「大見出し」と「小見出し」の2階層で構成する
・大見出しは必ず行頭に「◆ 」を付ける
・小見出しは必ず行頭に「◇ 」を付ける
・導入文のあとに「◆ はじめに」を置く
・その後、大見出しを3〜4個作り、それぞれの大見出しの中に小見出しを2個前後入れる
・最後は「◆ まとめ」にする
・各見出しは1行だけで書き、その次の行から本文を書く
・冒頭で悩みや疑問に共感し、記事を読むメリットを示す
・本文は具体例を入れ、初心者にも理解しやすくする
・過度な煽りや断定を避ける
・事実確認が必要な内容は断定しない
・最後に「まとめ」という見出しを入れて自然に締める
・noteで使いやすいハッシュタグを5〜8個提案する
・Markdownの見出し記号 # は使わない

必ず次の形式で出力してください。
タイトル：...
本文：
...
ハッシュタグ：#... #... #...
"""

    def generate_article(self):
        key = self._require_api()
        if not key:
            return
        try:
            prompt = self.build_article_prompt()
        except Exception as e:
            messagebox.showwarning("入力不足", str(e))
            return
        def work():
            return call_text_api(key, prompt, max_output_tokens=7000)
        def done(raw):
            title, body, tags = parse_article(raw)
            self.title_var.set(title or self.theme_var.get().strip())
            body = inject_note_toc(body)
            self.body_text.delete("1.0", "end")
            self.body_text.insert("1.0", body)
            self.tags_var.set(tags)
            self._apply_editor_formatting()
            self._update_char_count()
        self._run_bg(work, done, "note記事を生成中...")

    def build_image_prompt(self):
        title = self.title_var.get().strip() or self.theme_var.get().strip()
        if not title:
            raise ValueError("先にテーマまたは記事タイトルを入力してください。")
        body = self.body_text.get("1.0", "end").strip()
        body_hint = body[:800]
        style = self.image_style_var.get()
        return f"""Create a polished hero image base for a Japanese note article header.
Article title/theme: {title}
Article context: {body_hint}
Visual style: {style}
Requirements:
- very wide landscape composition, designed specifically for a note header
- target feeling is a 1280x670 banner, with the important subject large enough and not tiny
- keep the main subject medium-large and preferably center-right, leaving clear visual space on the left for a title overlay
- leave some calm empty space that can support title overlay
- clean, modern, bright, easy to understand at a glance
- no logos, no watermarks
- do not include readable text or typography in the image; the app will add the title later
- visually coherent with Japanese web editorial design
"""

    def generate_image(self):
        key = self._require_api()
        if not key:
            return
        try:
            prompt = self.build_image_prompt()
        except Exception as e:
            messagebox.showwarning("入力不足", str(e))
            return
        quality = self.image_quality_var.get()
        def work():
            raw = call_image_api(key, prompt, quality=quality)
            return crop_note_cover(raw, self.title_var.get().strip() or self.theme_var.get().strip())
        def done(data):
            self.image_bytes = data
            self._render_preview()
        self._run_bg(work, done, "見出し画像を生成中...")

    def _render_preview(self):
        self.image_canvas.delete("all")
        if not self.image_bytes:
            self.image_canvas.configure(scrollregion=(0, 0, 1, 1))
            self.image_canvas.create_text(20, 20, anchor="nw", text="まだ画像は生成されていません", fill="#7b849d", font=("Yu Gothic UI", 10))
            return
        try:
            from PIL import Image, ImageTk
            img = Image.open(BytesIO(self.image_bytes)).convert("RGB")
            self.preview_photo = ImageTk.PhotoImage(img)
            cw = max(300, self.image_canvas.winfo_width())
            ch = max(220, self.image_canvas.winfo_height())
            self.image_canvas.create_rectangle(0, 0, max(cw, img.width), max(ch, img.height), fill="#eef1f7", outline="")
            # Actual image is shown at full saved size so the whole cover can be checked using scrollbars.
            self.image_canvas.create_image(0, 0, image=self.preview_photo, anchor="nw")
            self.image_canvas.configure(scrollregion=(0, 0, img.width, img.height))
            self.image_canvas.xview_moveto(0)
            self.image_canvas.yview_moveto(0)
        except Exception:
            try:
                self.preview_photo = tk.PhotoImage(data=base64.b64encode(self.image_bytes).decode("ascii"))
                self.image_canvas.create_image(0, 0, image=self.preview_photo, anchor="nw")
                self.image_canvas.configure(scrollregion=(0, 0, self.preview_photo.width(), self.preview_photo.height()))
                self.image_canvas.xview_moveto(0)
                self.image_canvas.yview_moveto(0)
            except Exception:
                self.image_canvas.configure(scrollregion=(0, 0, 1, 1))
                self.image_canvas.create_text(20, 20, anchor="nw", text="画像は生成済みです。［画像を保存］から確認できます。", fill="#33415c", font=("Yu Gothic UI", 10))


    def _on_body_keyrelease(self, event=None):
        self._apply_editor_formatting()
        self._update_char_count()

    def refresh_toc(self):
        body = self.body_text.get("1.0", "end").strip()
        new_body = inject_note_toc(body)
        self.body_text.delete("1.0", "end")
        self.body_text.insert("1.0", new_body)
        self._apply_editor_formatting()
        self._update_char_count()
        self.status_var.set("目次を更新しました")

    def _apply_editor_formatting(self):
        for tag in ("heading_big", "heading_small", "toc_title", "toc_item", "toc_subitem", "keyword"):
            self.body_text.tag_remove(tag, "1.0", "end")

        content = self.body_text.get("1.0", "end-1c")
        lines = content.split("\n")
        in_toc = False
        keywords = ["ポイント", "コツ", "注意", "おすすめ", "重要", "結論", "原因", "対策", "メリット", "デメリット"]

        for idx, line in enumerate(lines, start=1):
            s = line.strip()
            line_start = f"{idx}.0"
            line_end = f"{idx}.end"
            if s == "目次":
                self.body_text.tag_add("toc_title", line_start, line_end)
                in_toc = True
            elif in_toc and s.startswith("・"):
                self.body_text.tag_add("toc_item", line_start, line_end)
            elif in_toc and (s.startswith("└") or s.startswith("　└")):
                self.body_text.tag_add("toc_subitem", line_start, line_end)
            else:
                level = _heading_level(s)
                if level == 2:
                    self.body_text.tag_add("heading_big", line_start, line_end)
                elif level == 3:
                    self.body_text.tag_add("heading_small", line_start, line_end)
                if s and not (s.startswith("・") or s.startswith("└") or s.startswith("　└")):
                    in_toc = False

            for word in keywords:
                pos = 0
                while True:
                    found = line.find(word, pos)
                    if found < 0:
                        break
                    self.body_text.tag_add("keyword", f"{idx}.{found}", f"{idx}.{found + len(word)}")
                    pos = found + len(word)

    def _update_char_count(self):
        body = self.body_text.get("1.0", "end").strip()
        self.char_count_var.set(f"本文 {len(body):,}文字")

    def copy_title(self):
        text = self.title_var.get().strip()
        if not text:
            return
        self.clipboard_clear(); self.clipboard_append(text)
        self.status_var.set("タイトルをコピーしました")

    def copy_body(self):
        body = self.body_text.get("1.0", "end").strip()
        tags = self.tags_var.get().strip()
        text = body + (("\n\n" + tags) if tags else "")
        if not text.strip():
            return
        self.clipboard_clear(); self.clipboard_append(text)
        self.status_var.set("本文をコピーしました")

    def copy_tags(self):
        tags = self.tags_var.get().strip()
        if not tags:
            return
        self.clipboard_clear(); self.clipboard_append(tags)
        self.status_var.set("ハッシュタグをコピーしました")

    def auto_fill_note(self):
        title = self.title_var.get().strip()
        body = self.body_text.get("1.0", "end").strip()
        if not title or not body:
            messagebox.showwarning("記事未生成", "先にタイトルと本文を作成してください。")
            return

        note_html, heading_items = build_note_html(body)

        def work():
            try:
                from selenium import webdriver
                from selenium.webdriver.chrome.options import Options
            except ImportError as e:
                raise RuntimeError("note自動入力に必要なSeleniumが見つかりません。START.cmdから起動し直してください。") from e

            options = Options()
            os.makedirs(NOTE_CHROME_PROFILE, exist_ok=True)
            options.add_argument(f"--user-data-dir={NOTE_CHROME_PROFILE}")
            options.add_argument("--start-maximized")
            options.add_experimental_option("detach", True)

            driver = self.note_driver
            try:
                if driver is None:
                    raise Exception()
                _ = driver.current_url
            except Exception:
                driver = webdriver.Chrome(options=options)
                self.note_driver = driver

            driver.get(NOTE_NEW_URL)
            deadline = time.time() + 180
            while time.time() < deadline:
                try:
                    ready = driver.execute_script('''
                        return !!document.querySelector('textarea[placeholder="記事タイトル"]')
                            && !!document.querySelector('.ProseMirror, [contenteditable="true"]');
                    ''')
                    if ready:
                        break
                except Exception:
                    pass
                time.sleep(1)
            else:
                raise RuntimeError("noteの記事編集画面を確認できませんでした。Chromeでnoteにログインして投稿画面を開いたあと、もう一度実行してください。")

            ok_title = driver.execute_script('''
                const title = arguments[0];
                const ta = document.querySelector('textarea[placeholder="記事タイトル"]');
                if (!ta) return false;
                const desc = Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype, 'value');
                if (desc && desc.set) desc.set.call(ta, title); else ta.value = title;
                ta.dispatchEvent(new Event('input', {bubbles:true}));
                ta.dispatchEvent(new Event('change', {bubbles:true}));
                ta.focus();
                return true;
            ''', title)

            ok_body = driver.execute_script('''
                const content = arguments[0];
                const el = document.querySelector('.ProseMirror') || document.querySelector('[contenteditable="true"]');
                if (!el) return false;
                el.focus();
                document.execCommand('selectAll', false, null);
                document.execCommand('delete', false, null);
                const dt = new DataTransfer();
                dt.setData('text/html', content);
                dt.setData('text/plain', '');
                el.dispatchEvent(new ClipboardEvent('paste', {clipboardData: dt, bubbles:true, cancelable:true}));
                el.dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'insertFromPaste', data:null}));
                el.dispatchEvent(new Event('change', {bubbles:true}));
                if (!el.querySelector('h2,h3') && el.innerText.trim().length < 10) {
                    document.execCommand('insertHTML', false, content);
                    el.dispatchEvent(new InputEvent('input', {bubbles:true, inputType:'insertText', data:null}));
                }
                return el.innerText.trim().length > 0;
            ''', note_html)

            if not ok_title or not ok_body:
                raise RuntimeError("noteの入力欄を操作できませんでした。note側の画面仕様が変わっている可能性があります。")

            time.sleep(2)
            heading_count = driver.execute_script('''
                const el = document.querySelector('.ProseMirror') || document.querySelector('[contenteditable="true"]');
                return el ? el.querySelectorAll('h2,h3').length : 0;
            ''')

            native_toc = False
            if heading_count:
                driver.execute_script('''
                    const el = document.querySelector('.ProseMirror') || document.querySelector('[contenteditable="true"]');
                    if (!el) return;
                    const firstHeading = el.querySelector('h2,h3');
                    let p = firstHeading ? firstHeading.previousElementSibling : null;
                    if (!p || p.tagName !== 'P') p = el.querySelector('p');
                    if (!p) return;
                    p.scrollIntoView({block:'center'});
                    p.dispatchEvent(new MouseEvent('mouseover', {bubbles:true}));
                    p.click();
                    const range = document.createRange();
                    range.selectNodeContents(p); range.collapse(true);
                    const sel = window.getSelection(); sel.removeAllRanges(); sel.addRange(range);
                ''')
                time.sleep(1)
                opened = driver.execute_script('''
                    const buttons = [...document.querySelectorAll('button')];
                    const b = buttons.find(x => {
                        const s = ((x.getAttribute('aria-label')||'') + ' ' + (x.getAttribute('title')||'') + ' ' + (x.textContent||'')).trim();
                        return /メニューを開く|挿入メニュー|ブロックを追加|追加/.test(s);
                    });
                    if (b) { b.click(); return true; }
                    return false;
                ''')
                if opened:
                    time.sleep(1)
                    native_toc = bool(driver.execute_script('''
                        const nodes = [...document.querySelectorAll('button,[role="menuitem"],li,div,span')];
                        const target = nodes.find(x => (x.textContent||'').trim() === '目次');
                        if (!target) return false;
                        let clickable = target;
                        for (let i=0; i<4 && clickable; i++) {
                            if (clickable.matches && (clickable.matches('button,[role="menuitem"]') || clickable.onclick)) break;
                            clickable = clickable.parentElement;
                        }
                        (clickable || target).click();
                        return true;
                    '''))
                    if native_toc:
                        time.sleep(1.5)

            return len(heading_items), native_toc

        def done(result):
            heading_count, native_toc = result
            toc_msg = "note標準の目次も自動挿入しました。" if native_toc else "見出しは設定済みです。目次だけは必要に応じて［＋］→［目次］を選んでください。"
            messagebox.showinfo(
                "自動入力完了",
                f"noteにタイトルと本文を整形して入力しました。\n\n"
                f"大見出し・小見出し：{heading_count}項目\n"
                f"{toc_msg}\n\n"
                "内容を確認してから、公開操作はご自身で行ってください。"
            )

        self._run_bg(work, done, "noteへ導入文・大見出し・小見出し・目次を整えて入力中...")

    def save_image(self):
        if not self.image_bytes:
            messagebox.showwarning("画像なし", "先に画像を生成してください。")
            return
        safe = re.sub(r'[\\/:*?"<>|]+', "_", self.title_var.get().strip() or "note_header")
        path = filedialog.asksaveasfilename(defaultextension=".png", initialfile=safe + "_header.png", filetypes=[("PNG画像", "*.png")])
        if path:
            try:
                # 念のため保存直前にも必ず1280×670pxへ整形する。
                final_image = crop_note_cover(self.image_bytes, self.title_var.get().strip() or self.theme_var.get().strip())
                self.image_bytes = final_image
                with open(path, "wb") as f:
                    f.write(final_image)
                messagebox.showinfo("保存完了", "見出し画像をタイトル入りの1280×670pxで保存しました。")
            except Exception as e:
                messagebox.showerror("保存エラー", str(e))

    def _show_update_available(self, latest):
        self.update_status_var.set(f"⚠ 新しいバージョンがあります：v{latest}\nアップデートしてください")
        try:
            self.update_status_label.configure(bg="#fff3b0", fg="#6b5200", font=("Yu Gothic UI", 10, "bold"))
        except Exception:
            pass
        self.update_button.configure(state="normal")

    def _show_update_current(self):
        self.update_status_var.set(f"v{APP_VERSION} は最新版です")
        try:
            self.update_status_label.configure(bg="#ffffff", fg="#68708a", font=("Yu Gothic UI", 9))
        except Exception:
            pass
        self.update_button.configure(state="disabled")

    def _silent_update_check(self):
        url = get_update_manifest_url()
        if not url:
            return
        def work():
            return fetch_json(url)
        def done(manifest):
            self.remote_update_manifest = manifest
            latest = str(manifest.get("version", "")).strip()
            if latest and _version_tuple(latest) > _version_tuple(APP_VERSION):
                self._show_update_available(latest)
                notes = manifest.get("notes", [])
                if isinstance(notes, str):
                    notes = [notes]
                note_text = "\n".join(f"・{n}" for n in notes[:6])
                message = (
                    f"新しいバージョン v{latest} があります。\n"
                    "アップデートしてください。\n\n"
                    + (note_text + "\n\n" if note_text else "")
                    + "今すぐアップデートしますか？"
                )
                if messagebox.askyesno("アップデートのお知らせ", message):
                    self.install_update()
            else:
                self._show_update_current()
        self._run_bg(work, done, "最新版を確認中...")

    def check_for_updates(self):
        url = get_update_manifest_url()
        if not url:
            messagebox.showinfo(
                "GitHub更新元が未設定",
                "アップデート機能は組み込み済みです。\n\n販売前に update_config.json の manifest_url にGitHub上の update.json のURLを設定してください。"
            )
            return
        def work():
            return fetch_json(url)
        def done(manifest):
            self.remote_update_manifest = manifest
            latest = str(manifest.get("version", "")).strip()
            if not latest:
                messagebox.showerror("更新確認エラー", "更新情報にversionがありません。")
                return
            if _version_tuple(latest) > _version_tuple(APP_VERSION):
                self._show_update_available(latest)
                notes = manifest.get("notes", [])
                if isinstance(notes, str):
                    notes = [notes]
                note_text = "\n".join(f"・{n}" for n in notes[:8])
                messagebox.showinfo("アップデートがあります", f"最新版 v{latest} が利用できます。\n\n{note_text}")
            else:
                self._show_update_current()
                messagebox.showinfo("最新版", "現在のバージョンが最新版です。")
        self._run_bg(work, done, "最新版を確認中...")

    def _combined_history(self):
        local = load_json_file(LOCAL_CHANGELOG_PATH, [])
        if not isinstance(local, list):
            local = []
        remote = []
        if isinstance(self.remote_update_manifest, dict):
            h = self.remote_update_manifest.get("history", [])
            if isinstance(h, list):
                remote = h
        by_version = {}
        for item in remote + local:
            if isinstance(item, dict) and item.get("version"):
                by_version[str(item["version"])] = item
        return sorted(by_version.values(), key=lambda x: _version_tuple(x.get("version")), reverse=True)

    def show_update_history(self):
        win = tk.Toplevel(self)
        win.title("更新履歴")
        win.geometry("650x520")
        win.configure(bg="#f6f7fb")
        frame = ttk.Frame(win)
        frame.pack(fill="both", expand=True, padx=16, pady=16)
        ttk.Label(frame, text="note記事自動作成ツール 更新履歴", style="Section.TLabel").pack(anchor="w", pady=(0, 8))
        box = scrolledtext.ScrolledText(frame, wrap="word", font=("Yu Gothic UI", 10), state="normal")
        box.pack(fill="both", expand=True)
        history = self._combined_history()
        if not history:
            box.insert("end", "更新履歴はまだありません。")
        for item in history:
            version = item.get("version", "")
            date = item.get("date", "")
            box.insert("end", f"v{version}" + (f"  ({date})" if date else "") + "\n")
            notes = item.get("notes", [])
            if isinstance(notes, str):
                notes = [notes]
            for note in notes:
                box.insert("end", f"  ・{note}\n")
            box.insert("end", "\n")
        box.configure(state="disabled")

    def install_update(self):
        manifest = self.remote_update_manifest
        if not isinstance(manifest, dict):
            messagebox.showwarning("更新情報なし", "先に［最新版を確認］を押してください。")
            return
        latest = str(manifest.get("version", "")).strip()
        url = str(manifest.get("download_url", "")).strip()
        if not latest or not url:
            messagebox.showerror("更新情報エラー", "更新情報に download_url がありません。")
            return
        if _version_tuple(latest) <= _version_tuple(APP_VERSION):
            messagebox.showinfo("最新版", "現在のバージョンが最新版です。")
            return
        if not messagebox.askyesno("アップデート", f"v{latest} にアップデートしますか？\n\nAPIキーや設定は引き継がれます。"):
            return
        def work():
            zip_path = os.path.join(tempfile.gettempdir(), f"note_article_auto_v{latest}.zip")
            download_file(url, zip_path)
            updater = build_temp_updater_script()
            return zip_path, updater
        def done(result):
            zip_path, updater = result
            self.update_status_var.set(f"v{latest} をインストールします...")
            try:
                self.update_status_label.configure(bg="#fff3b0", fg="#6b5200", font=("Yu Gothic UI", 10, "bold"))
            except Exception:
                pass
            try:
                subprocess.Popen([sys.executable, updater, zip_path, APP_DIR, str(os.getpid())], close_fds=True)
                messagebox.showinfo("アップデート開始", "最新版をインストールします。ツールはいったん終了し、更新後に再起動します。")
                self.after(300, self.destroy)
            except Exception as e:
                messagebox.showerror("アップデートエラー", str(e))
        self._run_bg(work, done, "最新版をダウンロード中...")

    def save_text(self):
        title = self.title_var.get().strip()
        body = self.body_text.get("1.0", "end").strip()
        tags = self.tags_var.get().strip()
        if not body:
            messagebox.showwarning("記事なし", "先に記事を生成してください。")
            return
        safe = re.sub(r'[\\/:*?"<>|]+', "_", title or "note_article")
        path = filedialog.asksaveasfilename(defaultextension=".txt", initialfile=safe + ".txt", filetypes=[("テキスト", "*.txt")])
        if path:
            with open(path, "w", encoding="utf-8-sig") as f:
                f.write(title + "\n\n" + body + ("\n\n" + tags if tags else ""))
            messagebox.showinfo("保存完了", "記事を保存しました。")

    def on_close(self):
        try:
            self._persist_api()
        except Exception:
            pass
        self.destroy()


if __name__ == "__main__":
    app = NoteAIAutoMaker()
    app.protocol("WM_DELETE_WINDOW", app.on_close)
    app.mainloop()
