@echo off
cd /d "%~dp0"
where py >nul 2>nul
if %errorlevel%==0 (
  py -m pip install -r requirements.txt
  py note_ai_auto_maker.py
  goto :end
)
where python >nul 2>nul
if %errorlevel%==0 (
  python -m pip install -r requirements.txt
  python note_ai_auto_maker.py
  goto :end
)
echo Python was not found on this PC.
echo Please install Python 3 and run START.cmd again.
pause
:end
